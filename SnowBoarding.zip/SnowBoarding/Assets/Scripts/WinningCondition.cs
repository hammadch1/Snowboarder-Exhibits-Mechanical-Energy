﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WinningCondition : MonoBehaviour {
	public GameObject SnowBoarder,Restart,WinBackGround,LostBackGround,Flag;
	public Text T;
	Vector3 lastPosition;
	float speed;
	bool IsTriggered;

	// Use this for initialization
	void Start () {
		// T=GetComponent<Text>();
		// T.enabled=false;
		lastPosition=Vector3.zero;
		LostBackGround=WinBackGround;
		IsTriggered=false;
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		speed = (SnowBoarder.transform.position - lastPosition).magnitude;
		lastPosition = SnowBoarder.transform.position;
	}
	void Update()
	{
		if(speed*1000==0 && Time.time>0 && SnowBoarder.transform.position.y<0)
		{
			if(IsTriggered==false)
				StartCoroutine("LostWait");
		}
	}

	IEnumerator WinWait()
	{
		yield return new WaitForSeconds(0.6f);
		T.gameObject.SetActive(true);
		WinBackGround.GetComponent<SpriteRenderer>().sortingOrder=2;
		WinBackGround.SetActive(true);
		Restart.SetActive(true);
		 //Time.timeScale=0;
	}

	IEnumerator LostWait()
	{
		yield return new WaitForSeconds(0.6f);
		T.gameObject.SetActive(true);
		T.text="You Lost";
		LostBackGround.GetComponent<SpriteRenderer>().sortingOrder=2;
		LostBackGround.SetActive(true);
		Restart.SetActive(true);
		//Time.timeScale=0;
	}

	void OnTriggerEnter2D(Collider2D other)
	{
		IsTriggered=true;
		print("object entered the trigger2D");
		// T.enabled=true;
		StartCoroutine("WinWait");
		// T.GetComponent<Text>().enabled=true;
	}
}
