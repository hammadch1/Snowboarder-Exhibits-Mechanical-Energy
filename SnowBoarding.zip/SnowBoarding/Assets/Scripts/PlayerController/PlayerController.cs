﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

	public float SpeedOfBoard;
	Rigidbody2D banda;
	public GameObject Banda,MountainSlope,Space;
	public Text StartGame;
	public float SpeedOfHeight;
    public float UpperLimitSC, LowerLimitSC;
	public float UpperLimitPos, LowerLimitPos;
	public GameObject W,S,UpA,DA;
	int count;

	// Use this for initialization
	void Start () {
		banda=Banda.GetComponent<Rigidbody2D>();
		banda.isKinematic=true;
		count=0;
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey(KeyCode.Space))
        {
			StartGame.gameObject.SetActive(false);
			Destroy(Space);
			Destroy(W);Destroy(S);Destroy(UpA);Destroy(DA);
			banda.isKinematic=false;
			count++;
		}    
		else if(count==0)
		{
			if (Input.GetKey(KeyCode.W))
			{
				MountainSlope.transform.localScale+=new Vector3(0,SpeedOfHeight*Time.deltaTime,0);
				MountainSlope.transform.position+=new Vector3(0,SpeedOfHeight*1.5f*Time.deltaTime,0);
			}
			if (Input.GetKey(KeyCode.S))
			{
				MountainSlope.transform.localScale -= new Vector3(0,SpeedOfHeight * Time.deltaTime, 0);
				MountainSlope.transform.position-=new Vector3(0,SpeedOfHeight*1.5f*Time.deltaTime,0);
			}
			Vector3 MyScale = MountainSlope.transform.localScale;
			Vector3 MyPos = MountainSlope.transform.position;
			MyScale.y = Mathf.Clamp(MyScale.y,LowerLimitSC,UpperLimitSC);
			MyPos.y=Mathf.Clamp(MyPos.y,LowerLimitPos,UpperLimitPos);
			MountainSlope.transform.localScale = MyScale;
			MountainSlope.transform.position=MyPos;
		}
	}
}
