﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class EnergyBehaviours : MonoBehaviour {
	Rigidbody2D rigidbody;
	public Text KE;
	public GameObject Banda,KERed2,KERed1,KEYellow2,KEYellow1,KEGreen3,KEGreen2,KEGreen1;
	public GameObject PERed2,PERed1,PEYellow2,PEYellow1,PEGreen3,PEGreen2,PEGreen1;
	public GameObject TMERed2,TMERed1,TMEYellow2,TMEYellow1,TMEGreen3,TMEGreen2,TMEGreen1;
	float kineticEnergy;
	public GameObject KEPoint1,KEPoint2,PEPoint1,TMEPoint1;
	
	// Use this for initialization
	void Start () {
		KE=GetComponent<Text>();
		rigidbody=Banda.GetComponent<Rigidbody2D>();
		KERed1.transform.position=KERed2.transform.position=KEYellow1.transform.position=KEYellow2.transform.position
		=KEGreen3.transform.position=KEGreen2.transform.position=KEGreen1.transform.position=KEPoint1.transform.position;
		PERed1.transform.position=PERed2.transform.position=PEYellow1.transform.position=PEYellow2.transform.position
		=PEGreen3.transform.position=PEGreen2.transform.position=PEGreen1.transform.position=PEPoint1.transform.position;
		TMERed1.transform.position=TMERed2.transform.position=TMEYellow1.transform.position=TMEYellow2.transform.position
		=TMEGreen3.transform.position=TMEGreen2.transform.position=TMEGreen1.transform.position=TMEPoint1.transform.position;
	}
	
	// Update is called once per frame
	void Update () {

	}
	IEnumerator Wait()
	{
		yield return new WaitForSeconds(0.2f);
	}
	void FixedUpdate () {
		
		 kineticEnergy=KineticEnergyFound(rigidbody)*50;
		//Debug.Log("ke " +(int)kineticEnergy);
		if(kineticEnergy>=0 && kineticEnergy<=80)
		{
			KEPoint1.SetActive(false);
			KERed2.SetActive(true);
		}	
		if(kineticEnergy>80 && kineticEnergy<=160)
		{
			KERed2.SetActive(false);
			KERed1.SetActive(true);
		}	
		if(kineticEnergy>160 && kineticEnergy<=240)
		{
			KERed1.SetActive(false);
			KEYellow1.SetActive(true);
		}	
		if(kineticEnergy>240 && kineticEnergy<=320)
		{
			KEYellow1.SetActive(false);
			KEYellow2.SetActive(true);
		}	
		if(kineticEnergy>320 && kineticEnergy<=400)
		{
			KEYellow2.SetActive(false);
			KEGreen3.SetActive(true);
		}	
		if(kineticEnergy>400 && kineticEnergy<=480)
		{
			KEGreen3.SetActive(false);
			KEGreen2.SetActive(true);
		}	
		if(kineticEnergy>480 && kineticEnergy<=600)
		{
			KEGreen2.SetActive(false);
			KEGreen1.SetActive(true);
		}	
	}

	float KineticEnergyFound(Rigidbody2D Banda)
    {
        float Ek = (rigidbody.mass * rigidbody.velocity.sqrMagnitude) / 2; // kinetic energy
        return Ek; // mechanical energy of an object;
    }
}