﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class HeightText : MonoBehaviour {

	// Use this for initialization
	Text T;
	 public GameObject Ground;
 
 	Vector3 Direction;
	 int Height;
	// Use this for initialization
	void Start () {
		T=GetComponent<Text>();
	}
	
	// Update is called once per frame
	void Update () {
		Direction = Ground.transform.position - transform.position;
 	    Height = (int)((Direction.y*5)-1.52f);
		T.text="Height: " + Height +"m";
	}
}