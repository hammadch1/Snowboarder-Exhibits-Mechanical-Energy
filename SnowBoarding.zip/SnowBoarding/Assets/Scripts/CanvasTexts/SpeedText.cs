﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpeedText : MonoBehaviour {

	Text T;
	public Text LostText,WinText;
	public float speed;
	public GameObject Banda,LostBackGround,Restart;
	Vector3 lastPosition;
	bool IsTriggered;
	// Use this for initialization
	void Start () {
		IsTriggered=false;
		T=GetComponent<Text>();
		lastPosition = Vector3.zero;
	}
	void FixedUpdate()
	{
		speed = (Banda.transform.position - lastPosition).magnitude;
		lastPosition = Banda.transform.position;
		
		T.text="Speed: " + Mathf.RoundToInt(speed*1000.0f) +" m/s";
	}
	// Update is called once per frame
	void Update () {

	}
}
