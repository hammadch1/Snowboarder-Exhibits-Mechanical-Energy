﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class KineticEnergy : MonoBehaviour {

	Rigidbody2D rigidbody;
	public Text KE;
	public GameObject Banda;
	float kineticEnergy;
	public GameObject EPoint1;
	public GameObject EPoint2;
	// Use this for initialization
	void Start () {
		KE=GetComponent<Text>();
		rigidbody=Banda.GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void FixedUpdate () {
		 kineticEnergy=KineticEnergyFound(rigidbody);
		 KE.text="KE= "+(int)(kineticEnergy*50)+" J";
		// Debug.Log("kinetic energy: "+(int)kineticEnergy*50);
	}

	float KineticEnergyFound(Rigidbody2D Banda)
    {
        float Ek = (rigidbody.mass * rigidbody.velocity.sqrMagnitude) / 2; // kinetic energy
        return Ek; // mechanical energy of an object;
    }
}
