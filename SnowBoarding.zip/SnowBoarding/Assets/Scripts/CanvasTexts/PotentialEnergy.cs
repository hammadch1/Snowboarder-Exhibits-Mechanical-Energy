﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PotentialEnergy : MonoBehaviour {

	 float potentialEnergy;
	 public float gravityConstant;
	 public GameObject Banda;
	 Rigidbody2D rigidbody;
     public Text PE;
	 Vector3 Direction;
	 float Height;

	[SerializeField] GameObject WinningPoint;

	// Use this for initialization
	void Start () {
		rigidbody=Banda.GetComponent<Rigidbody2D>();
         PE=GetComponent<Text>();
	}
	
	// Update is called once per frame
	void Update () {
		potentialEnergy = PotentialEnergyFound(rigidbody);
	}

	void FixedUpdate () {
         PE.text="PE= "+(int)(potentialEnergy)+" J";
		 //Debug.Log("Potential Energy: "+(int)potentialEnergy);
    }

	float PotentialEnergyFound(Rigidbody2D Banda)
     {
		 HeightFind();
         float Ep = (gravityConstant * Banda.GetComponent<Rigidbody2D>().mass*Height);
		 //Debug.Log("height of skier: " + Height);
         return Ep; // potential energy of an object;
     }

	 void HeightFind()
	 {
		 Direction = Banda.transform.position - WinningPoint.transform.position;
		 Height = (Direction.y*5)+1.62f;
	 }
}
