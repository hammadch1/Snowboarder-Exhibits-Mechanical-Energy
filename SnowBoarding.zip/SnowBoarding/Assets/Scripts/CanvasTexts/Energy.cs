﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Energy : MonoBehaviour {
     Rigidbody2D rigidbody;
     public Text TME;
     float mechanicalEnergy;
     public float gravityConstant;
	 public GameObject Banda;
   
     void Start () {
         //influencer = FindObjectOfType<Influencer>().GetComponent<Rigidbody>();
		 rigidbody=Banda.GetComponent<Rigidbody2D>();
         TME=GetComponent<Text>();
     }
     void Update () {

	}

     void FixedUpdate () {
         mechanicalEnergy = MechanicalEnergy(rigidbody);
         TME.text="TME= "+(int)(mechanicalEnergy*50)+" J";
		 //Debug.Log("Mechanical Energy: "+(int)mechanicalEnergy*50);
    }
 
     float MechanicalEnergy(Rigidbody2D Banda)
     {
         float Ek = rigidbody.mass * rigidbody.velocity.sqrMagnitude / 2; // kinetic energy
         float Ep = -gravityConstant * rigidbody.mass * Banda.mass / 
		 (Banda.transform.position - transform.position).magnitude; // potential energy
 
         return Ek+Ep; // mechanical energy of an object;
     }
}
